<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
    session_start() ;   

 
// echo $_SERVER['REMOTE_ADDR']  adresse ip ; 
 
$ip = $_SERVER['REMOTE_ADDR']; 
echo $ip ; 

if($ip=="89.158.225.93")
{

}
else 
{

}

if($ip=="::1")
{
    echo "sa marche" ; 
}
// Recuperation de l'IP du visiteur
$query = @unserialize(file_get_contents('http://ip-api.com/php/'.$ip)); //connection au serveur de ip-api.com et recuperation des données
if($query && $query['status'] == 'success') 
{
	//code avec les variables
	echo "Bonjour visiteur de " . $query['country'] . "," . $query['city'];
}
 
?>
</body>
</html>