<?php 
session_start() ; 
header("Access-Control-Allow-Origin: *");
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "all_ffa";
$statu= $_POST["statu"];
echo "oui" ; 
/*
switch ($statu) 
{     //Switch verificateur de la valeur en entre celons la valeur optenue le code réalise une tache
    //*1 case User verification si l'utilisateur existe dans la basse de donne avec le nom prenom 
    case "user":        
                            $users_name =$_POST["users_name"];
                            $user_date_bord =$_POST["user_date_bord"];
                            if($user_date_bord<20)
                            {
                                $user_date_bord = $user_date_bord+2000 ; 
                            }
                            else 
                            {
                                $user_date_bord = $user_date_bord+1900 ;
                            }
                            $user_sex = $_POST["user_sex"];

                           
                            // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }  
                    $users_last_name = "";
                    $users_first_name = "" ;
                    $verif1=false ;
                    $verif2=false ;
                    $verif3=false ;
                    $verif4=false ;
                    $users_nationality="FR";
                    $nombreS =0; 
                    $nombreSX =0; 
                    for($i = 0 ; $i <strlen($users_name) ; $i ++)
                    {   
                            if($users_name[$i]==" ")
                            {
                                $nombreS++;
                            }
                    } 
            $nomLong =false ;   
if($nombreS<3)
{
    for($i = 0 ; $i <strlen($users_name) ; $i ++)
    {   
        if($verif2==false)
        {        
            if($users_name[$i]!=" "AND $users_name[$i]!=")") 
            {
                $users_last_name = $users_last_name.$users_name[$i] ;             
            }
        }
        if($users_name[$i]==" ")
        {
            $verif2=true;
        }
        if($verif2==true)
        {        
            if($users_name[$i]!=" ")
            {
                if($users_name[$i]!="(" )
                {                
                    if($users_name[$i]!=")" AND $verif3==false)
                    {
                        $users_first_name = $users_first_name.$users_name[$i] ;   
                    }    
                }
                else 
                {
                    $verif3=true ;
                    $users_nationality="";
                }
            }
        }
        if($verif3==true )
        {        
            if($users_name[$i]!="(" AND $users_name[$i]!=")" )
            {           
                $users_nationality = $users_nationality.$users_name[$i];
            }    
        }
    }
}
else 
{
    for($i = 0 ; $i <strlen($users_name) ; $i ++)
    {
        if($nomLong==false)
        {
            $users_last_name = $users_last_name.$users_name[$i] ; 
        }
       if($users_name[$i]==" ")
       {
        $nombreSX++;
       }
       if($nombreSX==$nombreS-1)
       {          
           $users_first_name = $users_first_name.$users_name[$i] ; 
           $nomLong=true ; 
       }
    
    }   
}                  //  echo $users_nationality;
                    $users_last_name = strtolower($users_last_name); 
                    $users_first_name = strtolower($users_first_name); 
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }
                    $sql = 'SELECT * FROM `user` WHERE `users_first_name`="'.$users_first_name.'" AND `users_last_name`="'.$users_last_name.'" AND `user_date_bord`="'.$user_date_bord.'"';
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        // output data of each row
                        while($row = $result->fetch_assoc()) {
                        // echo $row["users_first_name"];
                        }
                    } else {
                        // Create connection
                        $conn2 = new mysqli($servername, $username, $password, $dbname);
                        // Check connection
                        if ($conn2->connect_error) {
                            die("Connection failed: " . $conn2->connect_error);
                        }
                        
                        $sql = "INSERT INTO user(users_first_name, users_last_name, user_date_bord,user_sex,users_nationality)
                        VALUES ('$users_first_name', '$users_last_name', '$user_date_bord','$user_sex','$users_nationality')";
                        
                        if ($conn2->query($sql) === TRUE) {
                           // echo "User add* ".$users_first_name;
                        } else {
                            echo "Error: " . $sql . "<br>" . $conn2->error;
                        }
                        
                        $conn2->close();
                    }
                    $conn->close();


                  echo $nombreS;
    break ; 
    case "epreuve": 
                    $epreuve_nom = $_POST["epreuve_nom"] ;
                    $epreuve_sex = $_POST["epreuve_sex"] ;
                    $epreuve_anne = $_POST["epreuve_anne"] ;
                    $epreuve_zone = $_POST["epreuve_zone"] ;
                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $sql = 'SELECT * FROM `epreuve` WHERE `epreuve_nom`="'.$epreuve_nom.'" AND `epreuve_anne`="'.$epreuve_anne.'" AND `epreuve_anne`="'.$epreuve_anne.'" AND `epreuve_zone`="'.$epreuve_zone.'"';
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // output data of each row
                        while($row = $result->fetch_assoc()) {
                            echo "Epreuve existante < :) >";
                        }
                    } else {    
                    // Create connection
                    $conn2 = new mysqli($servername, $username, $password, $dbname);
                    // Check connection
                    if ($conn2->connect_error) {
                        die("Connection failed: " . $conn2->connect_error);
                    }

                    $sql = "INSERT INTO epreuve (epreuve_nom,epreuve_sex,epreuve_zone,epreuve_anne)
                    VALUES ('$epreuve_nom','$epreuve_sex','$epreuve_zone','$epreuve_anne')";

                    if ($conn2->query($sql) === TRUE) {
                        echo "Epreuve ajouté ";
                    } else {
                        echo "Error: " . $sql . "<br>" . $conn2->error;
                    }
                    $conn2->close();
                    }
                    $conn->close();
break ;     
case "mon_club":
        $club_nom  = $_POST["club_nom"] ; 
        $club_region  = $_POST["club_region"] ; 
        $club_departement  = $_POST["club_departement"] ;
        // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }
                    $sql = 'SELECT * FROM `club` WHERE `club_nom`="'.$club_nom.'" AND `club_departement`="'.$club_departement.'"';
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // output data of each row
                        while($row = $result->fetch_assoc()) {                      
                        }
                    } else {

                        echo "0 results";                        
                                // Create connection
                                $conn2 = new mysqli($servername, $username, $password, $dbname);
                                // Check connection
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }
                                $sql = "INSERT INTO club (club_nom,club_region,club_departement)
                                VALUES ('$club_nom','$club_region','$club_departement')";

                                if ($conn2->query($sql) === TRUE) {
                                    echo "New record created successfully";
                                } else {
                                    echo "Error: " . $sql . "<br>" . $conn2->error;
                                }
                                $conn2->close();  
                    }
                    $conn->close(); 
        break ; 

        case "result_" :
                                          
                                $result_categoti = $_POST["result_categoti"] ; 
                                $result_epreuve_nom = $_POST["result_epreuve_nom"] ; 
                                $result_user_nom= $_POST["result_user_nom"] ; 
                                $result_perf = $_POST["result_perf"] ; 
                                $result_club_nom = $_POST["result_club_nom"] ; 
                                $result_ville_nom = $_POST["result_ville_nom"] ; 
                                $result_categoti = $_POST["result_categoti"] ; 
                                $result_date_perf = $_POST["result_date_perf"];
                                $verif1=false ;
                                $verif2=false ;
                                $verif3=false ;
                                $verif4=false ;                                
                                $valf = "" ;
                                $taille =  strlen($result_perf); 
                                $taille_date =  strlen( $result_date_perf); // 6
                                $jour="" ; 
                                $mois="" ; 
                                $anne="" ; 
                                $vr1 =false;
                                $vr2 =false;
                                $vr3 =false;
for($i = 0 ; $i<$taille_date; $i++)
{
    if($vr3==true)
    {      
        $anne = $anne.$result_date_perf[$i] ;
    } 
if($vr2==true AND $vr3==false)
{  
    if($result_date_perf[$i]!="/")
    {
       // echo  $result_date_perf[$i] ;
        $mois =$mois.$result_date_perf[$i]  ; 
        // ajoute le jour      
    }
    else 
    {
        $vr3 = true ;      
    }
}
    if($vr1==false)
    {
       
        if($result_date_perf[$i]!="/")
        {
           // echo  $result_date_perf[$i] ;
            $jour =$jour.$result_date_perf[$i]  ; 
            // ajoute le jour
        }
        else 
        {
            $vr2 = true ; 
        }
    }
    if($result_date_perf[$i]=="/")
    {
        $vr1=true ;  
    }
}
if($anne<35)
{
    $anne = $anne+2000;
}
else 
{
    $anne = $anne+1900;
}

$result_date_perf = $anne."/".$mois."/".$jour;
$test = false ; 
$result_personal_reccord = "" ; 
$valfinal = "" ; 
for($i = 0 ; $i<$taille  ;$i++)
{
    //echo $result_perf[$i];
    if($verif1==false)
    {        
        if($result_perf[$i]!="(" AND $result_perf[$i]!=" " AND $test==false)
        {
            $valfinal = $valfinal.$result_perf[$i] ;
        }
        if($result_perf[$i]=="(")
        {
            $test=true;
        }

    }
    if($result_perf[$i]=="R")
    {
        $result_personal_reccord= "RP" ;
        $verif1=true;
    }
}
$result_perf =  str_replace("''",".",$valfinal);
$SommeSpace=0;
$SommeSpaceX=0;
$etranger = 0;
$result_user_nomX = ""; 
$result_user_prenomX="" ; 
$result_X=0 ; 
for($i=0 ; $i<strlen($result_user_nom);$i++)
{    
    if($result_user_nom[$i]==" ")
    {
        $SommeSpace ++ ;
    }
    if($result_user_nom[$i]=="(")
    {
        $etranger ++ ;
    }
}
if($etranger==1)
{ 
    for($i=0 ; $i<strlen($result_user_nom);$i++)
    {    
        if($result_user_nom[$i]==" ")
        {
            $SommeSpaceX ++ ;        
        }
    
    if($SommeSpaceX<$SommeSpace-1)
    {
        $result_user_nomX=$result_user_nomX.$result_user_nom[$i] ; 
    }   else 
    {
        if($result_user_nom[$i]=="(")
        {
            $result_X ++ ; 
        }
        if($result_X==0)
        {
            $result_user_prenomX = $result_user_prenomX.$result_user_nom[$i] ; 
        }
    }
}

$result_user_nomX = strtolower($result_user_nomX);
$result_user_prenomX = strtolower($result_user_prenomX);
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }    
    $sql = 'SELECT * FROM `result` WHERE  `result_user_nom`="'.$result_user_nomX.'" AND `result_epreuve_nom`="'.$result_epreuve_nom.'" AND `result_date_perf`="'.$result_date_perf.'"';
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            //echo "id: " . $row["result_user_nom"];
        }
    } else {

        $conn2 = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn2->connect_error) {
            die("Connection failed: " . $conn2->connect_error);
        }

        $result_perf= str_replace("'",".",$result_perf);
        $sql2 = "INSERT INTO result (result_epreuve_nom,result_user_nom,result_user_prenom,result_perf,result_club_nom,result_ville_nom,result_categoti,result_date_perf,result_personal_reccord)
        VALUES ('$result_epreuve_nom','$result_user_nomX','$result_user_prenomX','$result_perf','$result_club_nom','$result_ville_nom','$result_categoti','$result_date_perf','$result_personal_reccord')";

        if ($conn2->query($sql2) === TRUE) {
          echo "New record created successfully";
        } else {
            echo "Error: " . $sql2 . "<br>" . $conn2->error;
        }
        $conn2->close();
    }
    $conn->close();        
}
else 
{
 for($i=0 ; $i<strlen($result_user_nom);$i++)
 {
    if($result_user_nom[$i]==" ")
    {
        $SommeSpaceX ++;
    }
    if($SommeSpaceX<$SommeSpace)
    {
        $result_user_nomX = $result_user_nomX.$result_user_nom[$i];
    }
    else 
    {
        $result_user_prenomX = $result_user_prenomX.$result_user_nom[$i];
    }
   }
$invitation = false ;  
$result_user_nomX = strtolower($result_user_nomX);
$result_user_prenomX = strtolower($result_user_prenomX);
$conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = 'SELECT * FROM `result` WHERE  `result_user_nom`="'.$result_user_nomX.'" AND `result_epreuve_nom`="'.$result_epreuve_nom.'" AND `result_date_perf`="'.$result_date_perf.'" ';
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            //echo "id: " . $row["result_user_nom"];
            echo "OK!!!!" ; 
        }
    } else {

        $conn2 = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn2->connect_error) {
            die("Connection failed: " . $conn2->connect_error);
        }   
    $sql2 = "INSERT INTO result (result_epreuve_nom,result_user_nom,result_user_prenom,result_perf,result_club_nom,result_ville_nom,result_categoti,result_date_perf,result_personal_reccord)
    VALUES ('$result_epreuve_nom','$result_user_nomX','$result_user_prenomX','$result_perf','$result_club_nom','$result_ville_nom','$result_categoti','$result_date_perf','$result_personal_reccord')";
        if ($conn2->query($sql2) === TRUE) {
           echo "New record created successfully";
        } else {
          //  echo "Error: " . $sql2 . "<br>" . $conn2->error;
        }
        $conn2->close();
    }
    $conn->close(); 
}         
              
            break ;  
}
*/
?>