<?php 
  include("all.php") ; 
?>
<script src="http://bokonzi.com/projets/ffa_datas/script.js"></script>