
<?php
header("Access-Control-Allow-Origin: *");
//echo "ok"  ; 
 echo $_POST["result_date_perf"] ; 
 
// $sex_epreuve =$_POST["sex_epreuve"] ; 
// $epreuve_zone= $_POST["epreuve_zone"] ; 
$servername = "localhost";
$username = "u481158665_all_ffa";
$password = "v3p9r3e@59A";
$dbname = "u481158665_all_ffa";


$result_nom_complet= $_POST["users_nom_complet"] ; 


echo "test2 ok ".$result_nom_complet ;
$result_perf = htmlspecialchars($_POST["result_perf"]);
$users_nom_complet =$_POST["users_nom_complet"];
$sex_epreuve =$_POST["sex_epreuve"];
$users_nationality =$_POST["users_nationality"];
$club_nom =$_POST["club_nom"];
$club_region =$_POST["club_region"];
$club_departement =$_POST["club_departement"];
$result_categoti =$_POST["result_categoti"];
$users_naissance =$_POST["users_naissance"];
$result_ville_nom =$_POST["result_ville_nom"];
$users_nom =$_POST["users_nom"];
$users_prenom =$_POST["users_prenom"];
$result_perf =$_POST["result_perf"];
$result_date_perf =$_POST["result_date_perf"];

$epreuve_zone = $_POST["epreuve_zone"] ;  
$result_commentaire= $_POST["result_commentaire"] ;
$result_personal_reccord = $_POST["result_personal_reccord"] ;  
$result_perf_2 = $_POST["result_perf_2"] ; 

$epreuve_nom = $_POST["epreuve_nom"] ; 





if($users_naissance>35)
{
    $users_naissance = $users_naissance+1900;
}
else 
{
    $users_naissance = $users_naissance+2000;
}
 
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = 'SELECT * FROM `club` WHERE `club_nom` ="'.$club_nom.'"';
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       // echo "id: " . $row["club_nom"] ;
    }
} else {
 

    // Create connection
    $conn2 = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn2->connect_error) {
        die("Connection failed: " . $conn2->connect_error);
    }
    
    $sql2 = "INSERT INTO club (club_nom, club_region,club_departement)
    VALUES ('$club_nom', '$club_region', '$club_departement')";
    
    if ($conn2->query($sql2) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql2 . "<br>" . $conn2->error;
    }
    
    $conn2->close();

}
$conn->close();

// Create connection
$conn3 = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn3->connect_error) {
    die("Connection failed: " . $conn3->connect_error);
}

$sql3 = 'SELECT * FROM `users` WHERE `users_nom_complet` ="'.$users_nom_complet.'"';
$result3 = $conn3->query($sql3);

if ($result3->num_rows > 0) {
    // output data of each row
    while($row3 = $result3->fetch_assoc()) {
     //   echo "id: " . $row3["users_nom_complet"] ;
    }
} else {

 

    // Create connection
    $conn4 = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn4->connect_error) {
        die("Connection failed: " . $conn4->connect_error);
    }
    
    $sql4 = "INSERT INTO users (users_nom_complet,users_nom,users_prenom,users_sex,users_naissance,users_nationality)
    VALUES ('$users_nom_complet', '$users_nom', '$users_prenom','$sex_epreuve','$users_naissance','$users_nationality')";
    
    if ($conn4->query($sql4) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql4 . "<br>" . $conn4->error;
    }
    
    $conn4->close();
}
$conn3->close(); 
  


// Create connection
$conn7 = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn7->connect_error) {
    die("Connection failed: " . $conn7->connect_error);
}

$sql7 = 'SELECT * FROM `users` WHERE `users_nom_complet` ="'.$users_nom_complet.'"';
$result7 = $conn7->query($sql7);

if ($result7->num_rows > 0) {
    // output data of each row
    while($row7 = $result7->fetch_assoc()) {
        $result_id_user =  $row7["users_id"];
         
    }
} 
$conn7->close();
echo $result_id_user ; 
 


// Create connection
$conn8 = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn8->connect_error) {
    die("Connection failed: " . $conn8->connect_error);
}

$sql8 = 'SELECT * FROM `result` WHERE `result_id_user`="'.$result_id_user.'" AND `result_perf`="'.$result_perf.'"';
$result8 = $conn8->query($sql8);

if ($result8->num_rows > 0) {
    // output data of each row
    while($row8 = $result8->fetch_assoc()) {
      echo  $row8["result_nom_complet"];
         
    }
} 
else 
{
// Create connection
$connx_1 = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($connx_1->connect_error) {
    die("Connection failed: " . $connx_1->connect_error);
}

$sqlx_1 = "INSERT INTO result (result_id_user,result_nom_complet,result_users_nom,result_users_prenom,result_epreuve_nom,result_perf,result_perf_2,result_club_nom,result_ville_nom,result_categoti,result_personal_reccord,result_date_perf,result_commentaire)
VALUES ('$result_id_user','$result_nom_complet','$users_nom','$users_prenom','$epreuve_nom','$result_perf','$result_perf_2','$club_nom','$result_ville_nom','$result_categoti','$result_personal_reccord','$result_date_perf','$result_commentaire')";

if ($connx_1->query($sqlx_1) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sqlx_1 . "<br>" . $connx_1->error;
}

$connx_1->close();
}
 
$conn8->close();
echo $_POST["result_commentaire"] ; 

?>



