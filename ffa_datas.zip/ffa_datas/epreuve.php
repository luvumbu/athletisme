
<?php
header("Access-Control-Allow-Origin: *");
//echo "ok"  ; 

$servername = "localhost";
$username = "u481158665_all_ffa";
$password = "v3p9r3e@59A";
$dbname = "u481158665_all_ffa";

$sex_epreuve =$_POST["sex_epreuve"] ; 
$epreuve_zone= $_POST["epreuve_zone"] ; 
$epreuve_nom = $_POST["epreuve_nom"] ; 

// Create connection
$conn5 = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn5->connect_error) {
    die("Connection failed: " . $conn5->connect_error);
}

$sql5 = 'SELECT * FROM `epreuve` WHERE `epreuve_nom`="'.$epreuve_nom.'" AND `epreuve_sex` ="'.$sex_epreuve.'" AND `epreuve_zone` ="'.$epreuve_zone.'" ';
$result = $conn5->query($sql5);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       
    }
} else {



     $conn_1 = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn_1->connect_error) {
        die("Connection failed: " . $conn_1->connect_error);
    }
    
    $sql_1 = "INSERT INTO epreuve (epreuve_nom,epreuve_sex,epreuve_zone)
    VALUES ('$epreuve_nom','$sex_epreuve','$epreuve_zone')";
    
    if ($conn_1->query($sql_1) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql_1 . "<br>" . $conn_1->error;
    }    
    $conn_1->close(); 
    
}
$conn5->close();
  
  ?>






















   <?php 


// // Create connection
// $conn7 = new mysqli($servername, $username, $password, $dbname);
// // Check connection
// if ($conn7->connect_error) {
//     die("Connection failed: " . $conn7->connect_error);
// }

// $sql7 = 'SELECT * FROM `users` WHERE `users_nom_complet` ="'.$users_nom_complet.'"';
// $result7 = $conn7->query($sql7);

// if ($result7->num_rows > 0) {
//     // output data of each row
//     while($row7 = $result7->fetch_assoc()) {
//         $result_id_user =  $row7["users_id"];
         
//     }
// } 
// $conn7->close();
// echo $result_id_user ; 
 


// // Create connection
// $conn8 = new mysqli($servername, $username, $password, $dbname);
// // Check connection
// if ($conn8->connect_error) {
//     die("Connection failed: " . $conn8->connect_error);
// }

// $sql8 = 'SELECT * FROM `result` WHERE `result_id_user`="'.$result_id_user.'" AND `result_perf`="'.$result_perf.'"';
// $result8 = $conn8->query($sql8);

// if ($result8->num_rows > 0) {
//     // output data of each row
//     while($row8 = $result8->fetch_assoc()) {
//       echo  $row8["result_nom_complet"];
         
//     }
// } 
// else 
// {







 

// // Create connection
// $connx_1 = new mysqli($servername, $username, $password, $dbname);
// // Check connection
// if ($connx_1->connect_error) {
//     die("Connection failed: " . $connx_1->connect_error);
// }

// $sqlx_1 = "INSERT INTO result (result_id_user,result_nom_complet,result_users_nom,result_users_prenom,result_epreuve_nom,result_perf,result_perf_2,result_club_nom,result_ville_nom,result_categoti,result_personal_reccord,result_date_perf,result_commentaire)
// VALUES ('$result_id_user','$result_nom_complet','$users_nom','$users_prenom','$epreuve_nom','$result_perf','$result_perf_2','$club_nom','$result_ville_nom','$result_categoti','$result_personal_reccord','$result_date_perf','$result_commentaire')";

// if ($connx_1->query($sqlx_1) === TRUE) {
//     echo "New record created successfully";
// } else {
//     echo "Error: " . $sqlx_1 . "<br>" . $connx_1->error;
// }

// $connx_1->close();
 

 











// }
 
// $conn8->close();



// echo $_POST["result_commentaire"] ; 


echo "test  ok " ; 
?>



