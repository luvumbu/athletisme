
function abc()
{
  var tagNameTr = document.getElementsByTagName("tr") ; 
  var quantite = parseInt(tagNameTr[0].children[5].children[0].childElementCount);
  var anne_epreuve_for= tagNameTr[1].innerText; 
  var anne_epreuve_for_verif =false ;
  var anne_epreuve ="";  
  var mon_epreuve_n = window.location.href ;  
  mon_epreuve_n =  parseInt(mon_epreuve_n[164]+mon_epreuve_n[165]+mon_epreuve_n[166]) ; 
  var epreuve_for = tagNameTr[2].textContent;
  var epreuve_verif = false;
  var nom_epreuve ="" ;
  var sex_epreuve ="";   
  var sex_verif = 0 ; 
  var epreuve_zone = 0 ;
  var nombreAthlethes =tagNameTr.length ; // exemple 235 personnes
  var quantiteElement =tagNameTr[3].childElementCount ; // 21 element 
  var users_nationality =""; 
  var users_nationality_verif = 0 ; 
  var nombre_spaces = 0 ;
  var nombre_spaces_verif = 0 ;
  var nombre_spaces_verif2 = 0 ;
  var users_nom = "";
  var users_prenom ="";
  var localhost="localhost_" ; 
  var result_commentaire ="" ;
  var result_personal_reccord = 0  ;
  var result_date_perf_add= 0 ;
  var result_value = "" ;  
  var up = 0 ; 
  var http=""; 
  monanne = anne_epreuve_for[37]+anne_epreuve_for[38]+anne_epreuve_for[39]+anne_epreuve_for[40] ;
 // anne de lepreuve 
  var epreuve_50m=105; 
  var epreuve_60m=107;
  var epreuve_200m =121;
  var epreuve_400m =141;
  var epreuve_800m =209 ;
  var epreuve_1000m =211 ; 
  var epreuve_3000m =231;
  var epreuve_50mH =304;
  var epreuve_60mH=309;
  var epreuve_hauteur =511 ;
  var epreuve_perche= 512;
  var epreuve_longeur = 513;
  var epreuve_tripeS=514 ;
  var epreuve_poidsh=657;
  // epreuve salle Homme 
  var epreuve_100m_pe =110 ; 
  var epreuve_200m_pe = 120;
  var epreuve_400m_pe = 140 ; 
  var epreuve_800m_pe = 208 ;
  var epreuve_1500_pe = 215 ;
  var epreuve_3000_pe = 230;
  var epreuve_5000_pe = 250;
  var epreuve_110m_pe = 313;
  var epreuve_400mh_pe_h = 342;
  var epreuve_3000ms_pe_h = 430 ;
  var epreuve_hauteur_pe=501;
  var epreuve_perche_pe = 502;
  var epreuve_longeur_pe = 503;
  var epreuve_tripeS_pe =504 ;
  var epreuve_poidsh_pe=607 ; 
  var epreuve_disque_pe_h = 620 ; 
  var epreuve_javelot_h = 681 ; 
  var epreuve_marteau_h = 637
  
  
  if( window.location.href[4]=="s" && localhost!="localhost")
  {   
    for(var i = 0 ; i<window.location.href.length ; i++)
    {
      
        if(i==4)
        {
          http=http+"" ; 
        } 
        else 
        {
          http=http+window.location.href[i] ; 
        }
        
    }
  location.replace(http+"&frmposition=0") ; 
  }
  /* */
  // BOUCLE POUR OPTENIR L'ANNE DE L'UTILISATEUR #B-1  -------------------------------------------------
  for(var  i = 0 ; i <anne_epreuve_for.length ; i++) //-------------------------------------------
   {   
     if(anne_epreuve_for[i]==":" && anne_epreuve_for_verif!=-1 )
     {
      anne_epreuve_for_verif =true ;     
     }
     else if (anne_epreuve_for[i]==",")
     {
      anne_epreuve_for_verif = -1;
     }
     else if(anne_epreuve_for_verif==true)
     {   
       if(anne_epreuve_for[i]!=" " && anne_epreuve_for[i]!=":")
       {
       anne_epreuve =  anne_epreuve+anne_epreuve_for[i] ; 
       }
     }
   }
   // FIN DE LA BOUBLE #B-1
  for (let i = 0; i < epreuve_for.length; i++)
  {  
    if(epreuve_for[i]=="-" || epreuve_for[i]=="|" && epreuve_verif==false)
    {      
        epreuve_verif =-1; 
        if(epreuve_for[i]=="-")
        {
          epreuve_zone = "SALLE" ; 
        }
        else 
        {
          epreuve_zone = "PLEIN AIR" ;
        }
    }
    else if(epreuve_verif==false)
    {
      if(epreuve_for[i]!=" ")
      {
        nom_epreuve = nom_epreuve+epreuve_for[i] ; 
      }
    } 
    if(epreuve_for[i]=="M")
    {
      sex_verif ++ ; 
    }
    else 
    {
      //alert() ; 
    }
  } 
  
  if(sex_verif==0)
  {
    sex_epreuve = "F" ;
  }
  else 
  {
    sex_epreuve ="M"; 
  }
  
  
  for(var i = 3 ; i<nombreAthlethes-1;i++)
  {
      result_perf = tagNameTr[i].children[2].innerText ;    //result_perf
      tagNameTr[i].children[4].innerText ;    // ?
      users_nom_complet = tagNameTr[i].children[6].innerText ;      //users_nom_complet
      club_nom = tagNameTr[i].children[8].innerText ;       //club_nom
      club_region = tagNameTr[i].children[10].innerText ;      //club_region
      club_departement = tagNameTr[i].children[12].innerText ;      //club_departement 
      result_categoti = tagNameTr[i].children[14].innerText ;      //result_categoti
      user_naissance = tagNameTr[i].children[16].innerText ;      //user_naissance
      result_date_perf = tagNameTr[i].children[18].innerText ;      //result_ville_nom
      result_ville_nom  =tagNameTr[i].children[20].innerText ; //result_date_perf
   //users_nom_complet.length 
   for(var x = 0 ; x<users_nom_complet.length ; x++)
   {   
     if(users_nom_complet[x]=="(")
     {
      users_nationality_verif ++ ;    
     } 
     else if(users_nationality_verif>0 && users_nom_complet[x]!=" " &&  users_nom_complet[x]!=")")
     {
      users_nationality = users_nationality+users_nom_complet[x] ;
     }
     else if(users_nom_complet[x]==" ") 
     {
      nombre_spaces  ++ ; 
     }
   }
  if(users_nationality_verif==0)
  {
    users_nationality = "FR" ; 
  } 
      if(users_nationality_verif!=0)
      {
      }
  
      for(var z = 0 ; z<users_nom_complet.length ; z++)
   {
    
    if(users_nom_complet[z]==" ")
    {
      nombre_spaces_verif ++ ;
    }
  
    if(users_nationality=="FR")
    {
      if(nombre_spaces_verif==nombre_spaces)
      {
      
      if(users_nom_complet[z]!=" ")
      {
        users_prenom = users_prenom +users_nom_complet[z];
      }
      }
      else 
      {
        users_nom = users_nom +users_nom_complet[z];
      }
    }
    else 
    {
      if(nombre_spaces_verif==nombre_spaces-1)
      {
      users_prenom = users_prenom +users_nom_complet[z];
   
      }
      else 
      {     
        if(users_nom_complet[z]=="(")
        {
          nombre_spaces_verif2 ++ ; 
        }
        else if(nombre_spaces_verif2==0) 
        {
          users_nom = users_nom +users_nom_complet[z];
        }
      }
    }
   }  
      var datas = new FormData();
      datas.append("users_nom_complet", users_nom_complet);
      datas.append("sex_epreuve", sex_epreuve);
      datas.append("users_nationality", users_nationality);    
      datas.append("club_nom", club_nom);
      datas.append("club_region", club_region);
      datas.append("club_departement", club_departement);
      datas.append("result_categoti", result_categoti);
      datas.append("users_naissance", user_naissance);
      datas.append("result_ville_nom", result_ville_nom);
      datas.append("users_nom", users_nom);
      datas.append("epreuve_nom",nom_epreuve);    
      datas.append("users_prenom", users_prenom);
      result_perf =result_perf.replace("''", '.');
      result_perf =result_perf.replace("'", '.');
      datas.append("result_perf", result_perf); 
      datas.append("epreuve_zone", epreuve_zone); 
      var taille_perf = result_perf.length ; 
      var position_vend = 0 ;
      var valeur_vend = "" ;  
      for(var h = 0 ; h<taille_perf ; h++ )
      {        
        if(result_perf[h]=="R")
          {        
            result_personal_reccord ++ ; 
          }
    
          if(result_perf[h]==" " || result_perf[h]=="(")
          {
            up ++ ; 
          }      
   
          if(result_perf[h]=="+")
          {        
                position_vend ++ ; 
          }
          else if(result_perf[h]=="-")
          {
            position_vend ++ ; 
            result_commentaire = result_commentaire+result_perf[h] ;          
          }           
          else if(result_perf[h]==")") 
          {
            position_vend = -1 ; 
          }
          else if(position_vend>0) 
          {
            result_commentaire = result_commentaire+result_perf[h] ; 
          } 
          if(result_perf[h]=="(")
          {
            result_date_perf_add ++ ;  
          }
          if(result_date_perf_add==0)
          {
            if(result_perf[h]!= " ")
            {
            result_value = result_value+result_perf[h] ;
            }
          }
      } 
      datas.append("result_commentaire", result_commentaire); 
      if(result_personal_reccord!=0)
      {
        result_personal_reccord = "RP";     
      }
      else 
      {
        result_personal_reccord = "" ; 
      }
      datas.append("result_personal_reccord", result_personal_reccord);
      datas.append("result_commentaire",result_commentaire);      
      var jour = "" ; 
      var mois= "" ; 
      var anne = "" ;
   for(var y = 0 ; y <result_date_perf.length ; y++)
  {
    if(y<2)
    {    
      jour = jour +result_date_perf[y] ; 
    }
    else if(y<5 &&  y>2)
    {
      mois = mois +result_date_perf[y] ; 
    }
    else if(y<8 &&  y>5)
    {
      anne = anne +result_date_perf[y] ; 
    } 
  }
  if(anne<35)
  {   
    anne = parseInt(anne)  ;
    anne = anne+2000 ;
  }
  var result_perf_2_verif = 0 ; 
   result_perf_2 ="00:";
  
  for(var x = 0 ; x<result_value.length ; x++)
  {
   
      if(result_perf_2_verif<5)
    {
          if(result_value[x]==".")
        {
          result_value[x] = ":";   
          result_perf_2 = result_perf_2+":" ;    
        }
        else 
        {
          result_perf_2 = result_perf_2+result_value[x] ; 
        }
    }
    result_perf_2_verif ++; 
  }

  
  result_date_perf = anne+"-"+mois+"-"+jour; 
  datas.append("result_date_perf", result_date_perf); 
  datas.append("result_perf", result_value);
  datas.append("result_perf_2", result_perf_2);  
          if(localhost=="localhost") 
      {   
          var reqs = new XMLHttpRequest();
          //reqs.open("POST", "php.php");
      }
      else 
      {
          var reqs = new XMLHttpRequest();
          reqs.open("POST", "http://bokonzi.com/projets/ffa_datas/php.php"); 
          // Envoi de la requête en y incluant l'objet
          reqs.send(datas);
          console.log(reqs); 
  
      }  
      // Envoi de la reqsuête en y incluant l'objet
     
   
      nombre_spaces_verif= 0 ; 
      users_nationality="" ; 
      users_nationality_verif = 0 ;
      nombre_spaces = 0 ;
      nombre_spaces_verif2 = 0 ;  
      users_nom =""; 
      users_prenom ="" ;   
      result_personal_reccord = 0 ;
      result_date_perf_add = 0 ;  
      result_commentaire="" ;    
      result_value = "" ;     
  }
  var http_length = http.length ;
  var http_nombre1 = "";
  var http_nombre2 = "";
  var http_nombre_verif_1=false ;
  var http_nombre_verif_2=false ;
  
  
  for(var i = 0 ; i<window.location.href.length-http_nombre2.length ; i++)
    {     
        if(i==4)
        {
          http=http+"" ; 
        } 
        else 
        {
          
          http=http+window.location.href[i] ; 
        }
        
    }
  
    var boucle = window.location.href.length;
  
    for(var i = boucle-1 ; i>-1 ; i--)
    {
      
        if(window.location.href[i]=="=")
        {
          i = -1 ; 
        }
        else 
        {
          http_nombre1 = http_nombre1 +window.location.href[i] ;
        } 
   
    }
  
  
    for(var i = boucle-1 ; i>-1 ; i--)
    {      
        if(window.location.href[i]=="=")
        {
          i = -1 ; 
        }  
    }      
  
    for(var i = http_nombre1.length-1 ; i>-1 ; i--)
    {      
      http_nombre2 = http_nombre2+http_nombre1[i]  ;    
    }  
  var http_redirection = "" ; 
   for( var i = 0 ; i <window.location.href.length-http_nombre2.length; i++)
   {
    http_redirection = http_redirection+window.location.href[i] ; 
   } 
  
   http_nombre2 = parseInt(http_nombre2)+1 ; 



   if(monanne=="2020")
   {
 
   http_redirection_2020 ="" ; 
   http_redirection_2020_2="" ; 
   for(var i = 0 ; i <http_redirection.length ;i++)
   {
     if(i ==105 ||i ==106 ||i ==107 ||i ==104  )
     {     
      // prend valeur de la boucle de 105 a 107 cest lanne 
     }
     else 
     {
      http_redirection_2020 =  http_redirection_2020+http_redirection[i];
     }
     if(i ==104)
     {
      http_redirection_2020 =  http_redirection_2020+"2004";
      //remplacer anne par 2004
     } 
   }
// test du code !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  var cool = 0 ; 
for(var i = 0 ; i <http_redirection_2020.length ;i++)
{
  // if(i ==105 ||i ==106 ||i ==107 ||i ==104  )
  // {     
  //  // prend valeur de la boucle de 105 a 107 cest lanne 
  // }
  // else 
  // {

  //  http_redirection_2020 =  http_redirection_2020+http_redirection[i];
  // }
  // if(i ==104)
  // {
  //  http_redirection_2020 =  http_redirection_2020+"2004";
  //  //remplacer anne par 2004
  // } 
  var nepreuve = http_redirection_2020[120]+http_redirection_2020[121]+http_redirection_2020[122];
  // numero de l'epreuve 
  var sex = http_redirection_2020[146];


  if(i ==120 ||i ==121 ||i ==122  )
  {     
  }
  else 
  {
   http_redirection_2020_2 =  http_redirection_2020_2+http_redirection[i];
  }
  if(i ==120)
  {

   
   

   switch(nepreuve) {
    case "104": // epreuve 50m    
    http_redirection_2020_2 =  http_redirection_2020_2+"105";   
   // redirection epreuve 50m salle
      break;
      case "105": //  50m salle 
      http_redirection_2020_2 =  http_redirection_2020_2+"107";   
     // redirection epreuve 60m 
        break;
        case "107": // epreuve 60m   salle  
        http_redirection_2020_2 =  http_redirection_2020_2+"110";   
       // redirection epreuve 100m salle
          break;
          case "110": // epreuve 100m    
          http_redirection_2020_2 =  http_redirection_2020_2+"120";   
         // redirection epreuve 200m salle
            break;
            case "120": // epreuve 200m    
            http_redirection_2020_2 =  http_redirection_2020_2+"121";   
           // redirection epreuve 200m salle
              break;
              case "121": // epreuve 200m salle    
              http_redirection_2020_2 =  http_redirection_2020_2+"130";   
             // redirection epreuve 300m salle
                break;
                case "130": // epreuve 300m    
                http_redirection_2020_2 =  http_redirection_2020_2+"131";   
               // redirection epreuve 300m salle
                  break;
                  case "131": // epreuve 50m    
                  http_redirection_2020_2 =  http_redirection_2020_2+"140";   
                 // redirection epreuve 400m 
                    break;
                    case "140": // epreuve 400m    
                    http_redirection_2020_2 =  http_redirection_2020_2+"141";   
                   // redirection epreuve 800m salle
                      break;
                      case "141": // epreuve 800m    
                      http_redirection_2020_2 =  http_redirection_2020_2+"208";   
                     // redirection epreuve 800m salle
                        break;



                        case "208": // epreuve 800m 
                        http_redirection_2020_2 =  http_redirection_2020_2+"209";   
                       // redirection epreuve  salle 1000m
                          break;
                          case "209": // epreuve 1000m    
                          http_redirection_2020_2 =  http_redirection_2020_2+"210";   
                         // redirection epreuve 1000m salle
                            break;
                            case "210": // epreuve 1000m salle    
                            http_redirection_2020_2 =  http_redirection_2020_2+"211";   
                           // redirection epreuve 1500m salle
                              break;
                              case "211": // epreuve 1500m    
                              http_redirection_2020_2 =  http_redirection_2020_2+"216";   
                             // redirection epreuve 2000 
                                break;
                                case "216": // epreuve 1500m salle    
                                http_redirection_2020_2 =  http_redirection_2020_2+"220";   
                               // redirection epreuve 800m salle
                                  break;
                                  case "220": // epreuve 2000m    
                                  http_redirection_2020_2 =  http_redirection_2020_2+"221";   
                                 // redirection epreuve 2000m salle
                                    break;
                                    case "221": // epreuve 3000m salle    
                                    http_redirection_2020_2 =  http_redirection_2020_2+"230";   
                                   // redirection epreuve 3000m salle
                                      break;                  





  }

  } 
}
 

http_redirection_2020 = http_redirection_2020_2;


// var epreuve_100m_pe =110 ; 
// var epreuve_200m_pe = 120;
// var epreuve_400m_pe = 140 ; 
// var epreuve_800m_pe = 208 ;
// var epreuve_1500_pe = 215 ;
// var epreuve_3000_pe = 230;
// var epreuve_5000_pe = 250;
// var epreuve_110m_pe = 313;
// var epreuve_400mh_pe_h = 342;
// var epreuve_3000ms_pe_h = 430 ;
// var epreuve_hauteur_pe=501;
// var epreuve_perche_pe = 502;
// var epreuve_longeur_pe = 503;
// var epreuve_tripeS_pe =504 ;
// var epreuve_poidsh_pe=607 ; 
// var epreuve_disque_pe_h = 620 ; 
// var epreuve_javelot_h = 681 ; 
// var epreuve_marteau_h = 637


















// fin du test du code  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

   
   

   setTimeout(function(){ 




    
 

    
    
    location.replace(http_redirection_2020+0) ; 
       
      
          }, 12000);
  
}
else 
{
  setTimeout(function(){ 
    location.replace(http_redirection+http_nombre2) ; 
       
      
          }, 12000);
}



 
 ;  
}
abc(); 
