-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 12, 2020 at 11:50 AM
-- Server version: 5.6.20-log
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `all_ffa`
--

-- --------------------------------------------------------

--
-- Table structure for table `club`
--

CREATE TABLE IF NOT EXISTS `club` (
`club_id` int(11) NOT NULL,
  `club_nom` varchar(50) NOT NULL,
  `club_region` varchar(50) NOT NULL,
  `club_departement` int(50) NOT NULL,
  `club_add_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `epreuve`
--

CREATE TABLE IF NOT EXISTS `epreuve` (
`epreuve_id` int(100) NOT NULL,
  `epreuve_nom` varchar(100) COLLATE utf8_bin NOT NULL,
  `epreuve_sex` varchar(5) COLLATE utf8_bin NOT NULL,
  `epreuve_zone` varchar(100) COLLATE utf8_bin NOT NULL,
  `epreuve_add_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE IF NOT EXISTS `result` (
`result_id` int(11) NOT NULL,
  `result_id_user` varchar(100) NOT NULL,
  `result_nom_complet` varchar(100) NOT NULL,
  `result_users_nom` varchar(50) NOT NULL,
  `result_users_prenom` varchar(50) NOT NULL,
  `result_epreuve_nom` varchar(100) NOT NULL,
  `result_perf` varchar(50) DEFAULT NULL,
  `result_club_nom` varchar(100) NOT NULL,
  `result_ville_nom` varchar(100) NOT NULL,
  `result_categoti` varchar(100) NOT NULL,
  `result_personal_reccord` varchar(5) NOT NULL,
  `result_date_perf` date NOT NULL,
  `result_commentaire` varchar(50) DEFAULT NULL,
  `result_date_add` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`users_id` int(11) NOT NULL,
  `users_nom_complet` varchar(100) NOT NULL,
  `users_nom` varchar(50) NOT NULL,
  `users_prenom` varchar(50) NOT NULL,
  `users_sex` varchar(50) NOT NULL,
  `users_naissance` int(100) NOT NULL,
  `users_nationality` varchar(50) NOT NULL,
  `users_datte_add` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `club`
--
ALTER TABLE `club`
 ADD PRIMARY KEY (`club_id`);

--
-- Indexes for table `epreuve`
--
ALTER TABLE `epreuve`
 ADD PRIMARY KEY (`epreuve_id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
 ADD PRIMARY KEY (`result_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`users_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `club`
--
ALTER TABLE `club`
MODIFY `club_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `epreuve`
--
ALTER TABLE `epreuve`
MODIFY `epreuve_id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `users_id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
